//
//  ViewController.swift
//  getAlamofireObjectMapper
//
//  Created by admin on 11/05/17.
//  Copyright © 2017 admin. All rights reserved.
//

import UIKit
import AlamofireObjectMapper
import Alamofire
class ViewController: UIViewController {

    @IBOutlet weak var sampleLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        getAlamofireMapperCall()
        getAlamofireMapperCall1()
    }

    func getAlamofireMapperCall() {
        let URL = "https://raw.githubusercontent.com/tristanhimmelman/AlamofireObjectMapper/d8bb95982be8a11a2308e779bb9a9707ebe42ede/sample_json"
        Alamofire.request(URL).responseObject { (response: DataResponse<WeatherResponse>) in
            
            let weatherResponse = response.result.value
            print(weatherResponse?.location)
            
            if let threeDayForecast = weatherResponse?.threeDayForecast {
                for forecast in threeDayForecast {
                    print(forecast.day)
                    print(forecast.temperature)
                    self.sampleLabel.text = forecast.day
                }
            }
        }
    }
    
    func getAlamofireMapperCall1() {
        let URL = "https://raw.githubusercontent.com/tristanhimmelman/AlamofireObjectMapper/d8bb95982be8a11a2308e779bb9a9707ebe42ede/sample_json"
        Alamofire.request(URL).responseArray { (response: DataResponse<[WeatherResponse]>) in
            
            let weatherResponse = response.result.value
            print(weatherResponse)
            
                    }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

